#How-to Intel code samples

These applications are how-to Intel IoT code sample exercises using the Intel® IoT Developer Kit, Intel® Edison development platform, cloud platforms, APIs, and other technologies. 

For instructions, refer to README.md for each code sample.
